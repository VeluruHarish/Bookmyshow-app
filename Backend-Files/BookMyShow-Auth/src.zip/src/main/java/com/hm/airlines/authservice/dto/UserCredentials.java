package com.hm.airlines.authservice.dto;

import lombok.Data;

@Data
public class UserCredentials {

	private String username;
	private String password;
	
	
}
