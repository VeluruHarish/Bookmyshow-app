package com.hm.airlines.authservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlinesAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
