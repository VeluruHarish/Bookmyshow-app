package com.hm.Capstoneproject.gmail.model;

import lombok.Data;

@Data
public class Role {
	private String roleName;
	private String roleDescription;


}
