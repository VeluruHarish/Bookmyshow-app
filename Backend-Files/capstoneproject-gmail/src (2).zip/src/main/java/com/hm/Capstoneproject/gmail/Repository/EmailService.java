package com.hm.Capstoneproject.gmail.Repository;

import com.hm.Capstoneproject.gmail.model.EmailDetails;

public interface EmailService {

	
	public String sendSimpleMail(EmailDetails details);
	
}
