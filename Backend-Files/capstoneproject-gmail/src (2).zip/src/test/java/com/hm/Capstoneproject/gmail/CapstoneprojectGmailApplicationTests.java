package com.hm.Capstoneproject.gmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneprojectGmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
