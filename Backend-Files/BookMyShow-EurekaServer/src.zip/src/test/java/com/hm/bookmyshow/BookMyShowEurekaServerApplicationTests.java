package com.hm.bookmyshow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
