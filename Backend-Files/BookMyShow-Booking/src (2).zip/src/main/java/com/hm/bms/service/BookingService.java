package com.hm.bms.service;

import java.util.List;

import com.hm.bms.dto.BookingRequest;
import com.hm.bms.model.Booking;

public interface BookingService {
	
	public List<Booking> getAllBookings();
	
//	public Booking getBookingById(int bookingid);
	
	public Booking saveBooking(BookingRequest bookingRequest);
	
//	public List<Booking> getBookingByShowId(int showId);
	
	public void getBooking();

}
