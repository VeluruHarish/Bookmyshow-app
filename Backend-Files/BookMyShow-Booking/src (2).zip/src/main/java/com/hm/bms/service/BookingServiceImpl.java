package com.hm.bms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import com.hm.bms.dto.BookingRequest;
import com.hm.bms.model.Booking;
import com.hm.bms.model.Multiplex;
import com.hm.bms.model.Seat;
import com.hm.bms.model.Show;
import com.hm.bms.repository.BookingRepo;

@Service
public class BookingServiceImpl implements BookingService {
	
	@Autowired
	BookingRepo repo;
	
	@Autowired
	RestTemplate rt;

	@Override
	public List<Booking> getAllBookings() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

//	@Override
//	public Booking getBookingById(int bookingid) {
//		// TODO Auto-generated method stub
//		return repo.getById(bookingid);
//	}

	@Override
	public Booking saveBooking(BookingRequest bookingRequest) {
//		System.out.println(booking.getBookedSeatIds());
		
		int showId= bookingRequest.getShowId();
		List<Integer> wantedSeats = bookingRequest.getBookedSeatIds();
		Show show = rt.getForObject("http://localhost:7999/show/"+showId, Show.class);
		List<Integer> bookedSeats = show.getBookedSeats();
		for (int seatId:wantedSeats) {
			if(bookedSeats.contains(seatId)) {
				System.out.println("already booked"+seatId);
				return null;
		}}
		List<Integer> seatNos= new ArrayList<>();
		for(int seatId:wantedSeats) {
			for(Seat seat:show.getScreen().getSeats()) {
				if(seat.getId()==seatId) {
					seatNos.add(seat.getSeatNo());
				}
			}
	
		}
		bookedSeats.addAll(bookingRequest.getBookedSeatIds());
		rt.postForObject("http://localhost:7999/show/"+bookingRequest.getShowId(), show, Show.class);
		Booking booking = new Booking();
		booking.setShowId(showId);
		booking.setShowtime(show.getStartTime());
		booking.setBookedSeatNos(seatNos);
		booking.setScreenName(show.getScreen().getName());
		Multiplex multiplex=rt.getForObject("http://localhost:7999/multiplex/screen/"+show.getScreen().getId(),Multiplex.class);
		booking.setMultiplexName(multiplex.getName());
		booking.setCityName(multiplex.getCity().getName());
		booking.setMultiplexAddress(multiplex.getAddress());
		booking.setMovieName(show.getMovie().getTitle());
		repo.save(booking);
		rt.postForObject("http://localhost:7997/bookingMail", booking, Booking.class);
		return booking;
		}

@Override
public void getBooking() {
	// TODO Auto-generated method stub
	Show show =rt.getForObject("http://localhost:7999/show/"+595, Show.class);
	rt.postForObject("http://localhost:7999/show/"+595, show, Show.class);
	
}
	
	
}
	



	
	
	
	

//	@Override
//	public List<Booking> getBookingByShowId(int showId) {
//		// TODO Auto-generated method stub
//		return repo.findByShowId(showId);
//	}


